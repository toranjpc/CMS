<template>
  <div>
    <h1>Admin Dashboard</h1>
  </div>
</template>

<script>
export default {
  layout: 'admin'
}
</script>
